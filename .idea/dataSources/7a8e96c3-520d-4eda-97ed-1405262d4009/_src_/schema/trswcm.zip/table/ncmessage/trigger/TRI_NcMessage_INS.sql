CREATE TRIGGER TRI_NcMessage_INS
AFTER INSERT ON ncmessage
FOR EACH ROW
  begin update NcSite set MessageCount = MessageCount+1 where  id=new.SiteID; update NcChannel set MessageCount = MessageCount+1 where  id=new.ChannelID; update NcNews set MessageCount = MessageCount+1 where  id=new.NewsID; end;
