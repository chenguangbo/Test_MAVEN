CREATE TRIGGER TRI_NcMessage_DEL
AFTER DELETE ON ncmessage
FOR EACH ROW
  begin update NcSite set MessageCount = MessageCount-1 where  id=old.SiteID; update NcChannel set MessageCount = MessageCount-1 where  id=old.ChannelID; update NcNews set MessageCount = MessageCount-1 where  id=old.NewsID; end;
