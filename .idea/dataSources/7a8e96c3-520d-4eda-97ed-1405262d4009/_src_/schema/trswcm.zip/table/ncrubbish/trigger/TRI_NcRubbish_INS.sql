CREATE TRIGGER TRI_NcRubbish_INS
AFTER INSERT ON ncrubbish
FOR EACH ROW
  begin update NcSite set RubbishCount = RubbishCount+1 where  id=new.SiteID; update NcChannel set RubbishCount = RubbishCount+1 where  id=new.ChannelID; update NcNews set RubbishCount = RubbishCount+1 where  id=new.NewsID; end;
