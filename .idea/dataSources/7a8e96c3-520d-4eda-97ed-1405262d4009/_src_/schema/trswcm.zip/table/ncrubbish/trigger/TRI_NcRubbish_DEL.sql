CREATE TRIGGER TRI_NcRubbish_DEL
AFTER DELETE ON ncrubbish
FOR EACH ROW
  begin update NcSite set RubbishCount = RubbishCount-1 where  id=old.SiteID; update NcChannel set RubbishCount = RubbishCount-1 where  id=old.ChannelID; update NcNews set RubbishCount = RubbishCount-1 where  id=old.NewsID; end;
