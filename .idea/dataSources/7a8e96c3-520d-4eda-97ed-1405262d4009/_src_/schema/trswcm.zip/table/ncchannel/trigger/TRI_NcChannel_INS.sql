CREATE TRIGGER TRI_NcChannel_INS
AFTER INSERT ON ncchannel
FOR EACH ROW
  begin update NcSite set ChannelCount = ChannelCount+1 where id=new.SiteID;  end;
