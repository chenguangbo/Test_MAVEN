CREATE TRIGGER TRI_NcChannel_DEL
AFTER DELETE ON ncchannel
FOR EACH ROW
  begin update NcSite set ChannelCount = ChannelCount-1 where id=old.SiteID;  end;
