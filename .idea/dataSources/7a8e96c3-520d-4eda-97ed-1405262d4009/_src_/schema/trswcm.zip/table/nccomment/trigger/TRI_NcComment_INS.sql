CREATE TRIGGER TRI_NcComment_INS
AFTER INSERT ON nccomment
FOR EACH ROW
  begin update NcSite set CommentCount = CommentCount+1 where  id=new.SiteID; update NcChannel set CommentCount = CommentCount+1 where  id=new.ChannelID; update NcNews set CommentCount = CommentCount+1 where  id=new.NewsID; end;
