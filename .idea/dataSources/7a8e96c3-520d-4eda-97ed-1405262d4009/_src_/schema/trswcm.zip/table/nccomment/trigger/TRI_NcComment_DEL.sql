CREATE TRIGGER TRI_NcComment_DEL
AFTER DELETE ON nccomment
FOR EACH ROW
  begin update NcSite set CommentCount = CommentCount-1 where id=old.SiteID; update NcChannel set CommentCount = CommentCount-1 where id=old.ChannelID; update NcNews set CommentCount = CommentCount-1 where id=old.NewsID;  end;
